const ADD_TRAINER = "ADD_TRAINER";
const SELECT_TRAINER = "SELECT_TRAINER";
const DELETE_TRAINER = "DELETE_TRAINER";
const UPDATE_TRAINER = "UPDATE_TRAINER";

// eslint-disable-next-line import/no-anonymous-default-export
export default {
  ADD_TRAINER,
  SELECT_TRAINER,
  DELETE_TRAINER,
  UPDATE_TRAINER,
};
