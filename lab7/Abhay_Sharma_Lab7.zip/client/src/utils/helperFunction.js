const calPageCount = (count) => {
  return Math.ceil(count / 20);
};

export { calPageCount };
