1. cd server 
2. npm i and then do npm start => it will start on 4000 port
3. cd client
4. npm i and then do npm start => should run on port 3000

Note: Remember to clear redis cache.